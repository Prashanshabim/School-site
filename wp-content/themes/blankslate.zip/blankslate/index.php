<?php /* Template Name: Home */?>
<?php get_header(); ?>

  <!-- ***** Main Banner Area Start ***** -->
  <section class="section main-banner" id="top" data-section="section1">
      <video autoplay muted loop id="bg-video">
          <source src="<?php echo get_template_directory_uri(); ?>/assets/images/background.mp4" type="video/mp4" />
      </video>

      <div class="video-overlay header-text">
          <div class="caption">
              <h6>Shree Saraswati Higher Secondary School</h6>
              <h2><em>Quality</em> Education</h2>
          </div>
      </div>
  </section>
  <!-- ***** Main Banner Area End ***** -->


  <section class="features">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-12">
          <div class="features-post">
            <div class="features-content">
              <div class="content-show">
                <h4><i class="fa fa-pencil"></i>Our Courses</h4>
              </div>
              <div class="content-hide">
                <p>Shree Saraswati provide quality education from primary to higher secondary level.We provide faculties of Management,Education also CTVT courses.</p>
                <p class="hidden-sm">Curabitur id eros vehicula, tincidunt libero eu, lobortis mi. In mollis eros a posuere imperdiet.</p>
                
            </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-12">
          <div class="features-post second-features">
            <div class="features-content">
              <div class="content-show">
                <h4><i class="fa fa-graduation-cap"></i>Virtual Class</h4>
              </div>
              <div class="content-hide">
                <p>We also provide learning through multimedia. Interactive Technical eduaction not only helps student academically but practically also. </p>
                <p class="hidden-sm">Curabitur id eros vehicula, tincidunt libero eu, lobortis mi. In mollis eros a posuere imperdiet.</p>
                
            </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-12">
          <div class="features-post third-features">
            <div class="features-content">
              <div class="content-show">
                <h4><i class="fa fa-book"></i>Real Meeting</h4>
              </div>
              <div class="content-hide">
                <p>we conduct regular meeting with Class RepresentativeTeachers and Parents which have helped us to improve our education services more.Feedback is the breakfast of champions.  </p>
                <p class="hidden-sm">Curabitur id eros vehicula, tincidunt libero eu, lobortis mi. In mollis eros a posuere imperdiet.</p>
                
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section why-us" data-section="section2">
  
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-heading">
            <h2>Why to choose Shree Saraswati H.S School?</h2>
          </div>
        </div>
        <div class="col-md-12">
          <div id='tabs'>
            <ul>
              <li><a href='#tabs-1'><?php echo get_field('title');?></a></li>
              <li><a href='#tabs-2'><?php echo get_field('title1');?></a></li>
              <li><a href='#tabs-3'><?php echo get_field('title2');?></a></li>
            </ul>
            <section class='tabs-content'>
              <article id='tabs-1'>
                <div class="row">
                  <div class="col-md-6">
                    <img src="<?php echo get_field('image',5);?>" alt="">
                  </div>
                  <div class="col-md-6">
                    <h4><?php echo get_field('title');?></h4>
                    <p><?php echo get_field('content');?></p>
                  </div>
                </div>
              </article>
              <article id='tabs-2'>
                <div class="row">
                  <div class="col-md-6">
                    <img src="<?php echo get_field('image1',5);?>" alt="">
                  </div>
                  <div class="col-md-6">
                    <h4><?php echo get_field('title1');?></h4>
                    <p><?php echo get_field('content1');?></p>
                  </div>
                </div>
              </article>
              <article id='tabs-3'>
                <div class="row">
                  <div class="col-md-6">
                    <img src="<?php echo get_field('image2',5);?>" alt="">
                  </div>
                  <div class="col-md-6">
                    <h4><?php echo get_field('title2');?></h4>
                    <p><?php echo get_field('content2');?> </p>
                  </div>
                </div>
              </article>
            </section>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- <section class="section coming-soon" data-section="section3">
    <div class="container">
      <div class="row">
        <div class="col-md-7 col-xs-12">
          <div class="continer centerIt">
            <div>
              <h4>We <em>provide Quality</em> services 24/7</h4>
              <div class="counter">

                <div class="days">
                  <div class="value">00</div>
                  <span>Days</span>
                </div>

                <div class="hours">
                  <div class="value">00</div>
                  <span>Hours</span>
                </div>

                <div class="minutes">
                  <div class="value">00</div>
                  <span>Minutes</span>
                </div>

                <div class="seconds">
                  <div class="value">00</div>
                  <span>Seconds</span>
                </div>

              </div>
            </div>
          </div>
        </div>
        <div class="col-md-5">
          <div class="right-content">
            <div class="top-content">
              <h6>Quality Education<em> & Interactive Learning</em> is our motto</h6>
            </div>
            <div class="stripe">
              <h4 style="text-decoration: underline;">Call Us</h4>
                <p>Shree Saraswati H.S. School,Near Hanuman Mandir,<br>
                    Ram Janaki Path, Biratnagar-12<br>
                    Phone: 9805334446/021-625121<br>
                </p>
              </div>
          </div>
        </div>
      </div>
    </div>
  </section> -->

  <section class="section courses" data-section="section4">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="section-heading">
            <h2>Our Gallery</h2>
          </div>
        </div>
        <div class="owl-carousel owl-theme">
        <?php $slider = get_posts(array('post_type' => 'gallery', 'posts_per_page' =>11)); ?>
      <?php $count = 0; ?>
      <?php foreach($slider as $slide): ?>
        <div class="item">
        <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($slide->ID)) ?>" alt="Course #1">
            <div class="down-content">
            <h4><?php echo $slide->post_title; ?></h4>
            <p><?php echo $slide->post_content; ?></p>
            </div>
          </div>
          
          <?php $count++; ?>
          <?php endforeach; ?>

          </div>
        </div>
      </div>
    </div>
  </section>
  

  <section class="section video" data-section="section5">
    <div class="container bg-dark">
      <div class="row">
        <div class="col-md-6 align-self-center">
          <div class="left-content">
            <span>Today a reader, tomorrow a leader</span>
            <h4><em>Principle's Voice</em></h4>
            <p>Our school is one of the oldest school of Biratnagar providing education from last 23 years continiously. We not only provide education to the primary level but also to the higher secondary level along with various faculties where the education is being provided by fully experienced teachers.We also provide CTVT courses of technical background under grovernment certification.We  provide education on theoritical, practical and experimental basis.
            <br><br>
            We not only provide education inside the four walls but our curriculum also includes outdoor studies, recreational activites, field visit,tours,seminars and many more.</p>
            <div class="main-button"><a rel="nofollow" href="#" target="_parent">Quality Focused</a></div>
          </div>
        </div>
        <div class="col-md-6">
          <article class="video-item">
            <div class="video-caption">
              <h4>Mr.Yogendra B. Karki</h4>
            </div>
            <figure>
              <img src="<?php echo get_template_directory_uri(); ?>/assets/images/principle.png"/>
            </figure>
          </article>
        </div>
      </div>
    </div>
  </section>

  <section class="section courses" data-section="section4">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="section-heading">
            <h2>News and Events</h2>
          </div>
        </div>
        <div class="owl-carousel owl-theme">
        <?php $slider = get_posts(array('post_type' => 'gallery', 'posts_per_page' =>11)); ?>
      <?php $count = 0; ?>
      <?php foreach($slider as $slide): ?>
        <div class="item">
        <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($slide->ID)) ?>" alt="Course #1">
            <div class="down-content">
            <h4><?php echo $slide->post_title; ?></h4>
            <p><?php echo $slide->post_content; ?></p>
            </div>
          </div>
          
          <?php $count++; ?>
          <?php endforeach; ?>

          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section contact" data-section="section6">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-heading">
            <h2>Let’s Keep In Touch</h2>
          </div>
        </div>
        <div class="col-md-6">
          <?php 
            echo do_shortcode('[contact-form-7 id="87" title="quote"]');
            ?>
        </div>
        <div class="col-md-6">
          <div id="map">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3572.3961423041605!2d87.28416871487256!3d26.44295678333219!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39ef74349b85b5a9%3A0x39d2163b974924ad!2sSaraswati%20Secondary%20School!5e0!3m2!1sen!2snp!4v1661689569783!5m2!1sen!2snp" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div>
        </div>
      </div>
    </div>
    <div class="stripe">
      <h4 style="text-decoration: underline;">Call Us</h4>
        <br>
        <p>Shree Saraswati H.S. School,<br>
          Near Hanuman Mandir,<br>
          Ram Janaki Path, Biratnagar-12<br>
          Phone: 9805334446/021-625121<br>
          Email: shreesaraswati5@gmail.com<br>
        </p>
    </div>
  </section>
<?php get_footer(); ?>