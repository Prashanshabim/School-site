<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <title>Shree Saraswati Higher Secondary School</title>
    
    <!-- Bootstrap core CSS -->
    <link href="<?php echo get_template_directory_uri(); ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/fontawesome.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/templatemo-grad-school.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/owl.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/lightbox.css">
    <style>
      .stripe {
	      background-image: #fff;
        color: #fff;
	      padding: 3rem;
	      height: 13rem;
        width: 27rem;
	      margin-top: 4rem;
        margin-left: 38%;
	      /*transform: rotate(10deg);*/
	      z-index: -5;
        text-align:center;
  justify-content: center;
      }
    </style>
    <?php wp_head(); ?>
  </head>

<body>

   
  <!--header-->
  <header class="main-header clearfix" role="header">
    <div class="logo">
      <a href="<?php echo home_url(); ?>"><em>Shree </em>Saraswati</a>
    </div>
    <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
    <nav id="menu" class="main-nav" role="navigation">
      <ul class="main-menu">
        <li><a href="<?php echo home_url();?>">Home</a></li>
        <li><a targer="_blank" href="<?php echo home_url();?>/about">About</a>
        </li>
        <li><a href="<?php echo home_url();?>/gallery-now">Gallery</a></li>
        <li><a href="<?php echo home_url();?>/news-events">News & Events</a></li>
        <li><a href="<?php echo home_url();?>/contact">Contact</a></li>
      </ul>
    </nav>
  </header>
