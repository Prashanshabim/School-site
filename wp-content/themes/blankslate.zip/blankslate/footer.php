<footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <p> Copyright <i class="fa fa-copyright"></i> 2022 All Rights Reserved 
            <br> Designed By: Prashansha Luitel
        </div>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
    <script src="<?php echo get_template_directory_uri(); ?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/isotope.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/owl-carousel.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/lightbox.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/tabs.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/video.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/slick-slider.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/custom.js"></script>
    
    </script>
    <?php wp_footer(); ?>
</body>
</html>